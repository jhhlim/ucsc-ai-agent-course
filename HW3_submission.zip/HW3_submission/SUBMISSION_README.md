# HW3 Submission — Multi-Agent Mortgage Explainer

**Student:** Jason Lim · **Course:** UCSC AI Agent Applications

| Folder | Contents |
|--------|----------|
| `code/` | Agents, tools, orchestrator, LangSmith eval |
| `output_examples/` | CLI + Web screenshots, eval results |
| `learnings/` | Project learnings document |

Run from course `src/`: `uv run python ../HW3_submission/code/run_scenario.py`
