# HW3 Submission — Multi-Agent Mortgage Explainer

**Student:** Jason Lim  
**Course:** UCSC AI Agent Applications

## Contents

| Folder | Requirement | Contents |
|--------|-------------|----------|
| `code/` | Code | Multi-agent mortgage system (ADK agents, orchestrator, tools, LangSmith eval) |
| `output_examples/` | Output examples | CLI + Web ADK sample prompts with screenshots; LangSmith eval results |
| `learnings/` | Learning | Challenges, observations, surprises, and what I would do differently |

## How to run (from course `src/` folder)

```bash
# Deterministic calculator (no LLM)
uv run python ../HW3_submission/code/run_scenario.py

# ADK CLI
uv run adk run ../HW3_submission/code/adk_agents/mortgage_supervisor

# ADK Web UI
uv run adk web ../HW3_submission/code/adk_agents --port 8000
```

Copy API keys from `src/env.example` into `src/.env` before running LLM-backed modes.
